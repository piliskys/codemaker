prompt PL/SQL Developer import file
prompt Created on 2015��3��6�� by liuquanbing
set feedback off
set define off
prompt Creating TB_STOCK_MAIN...
create table TB_STOCK_MAIN
(
  name     VARCHAR2(40),
  code     VARCHAR2(40),
  end_date DATE
)
tablespace BAS_BD_DATA_TBS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt Loading TB_STOCK_MAIN...
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ַ�����', '600000.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600001.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��³����', '600002.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ST������', '600003.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ƻ���', '600004.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600006.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й���ó', '600007.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�״��ɷ�', '600008.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ϻ�����', '600009.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ֹɷ�', '600010.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ܹ���', '600011.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ͨ����', '600012.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600016.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ո�', '600017.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ϸۼ���', '600018.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ֹɷ�', '600019.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ԭ����', '600020.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ϻ�����', '600021.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ɽ������', '600022.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�к���չ', '600026.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '600027.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й�ʯ��', '600028.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ϸ�����', '600029.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����֤ȯ', '600030.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��һ�ع�', '600031.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600033.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600036.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�軪����', '600037.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ֱ�ɷ�', '600038.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ĵ�·��', '600039.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ز�', '600048.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й���ͨ', '600050.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600051.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�н��ز�', '600053.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ɽ����', '600054.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '600055.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й�ҽҩ', '600056.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '600057.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���չ', '600058.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Խ��ɽ', '600059.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�з�Ͷ��', '600061.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����˫��', '600062.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ά����', '600063.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ͼ��߿�', '600064.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST����', '600065.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ͨ�ͳ�', '600066.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ڳǴ�ͨ', '600067.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ͷ��', '600069.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�㽭����', '600070.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��˹�ѧ', '600071.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST�ֹ�', '600072.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ϻ�÷��', '600073.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�д�ɷ�', '600074.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���񻪹�', '600076.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ζ��ɷ�', '600077.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ǹɷ�', '600078.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�˸�ҽҩ', '600079.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�𻨹ɷ�', '600080.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ƽ�', '600081.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��̩��չ', '600082.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ϲɷ�', '600084.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ͬ����', '600085.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600086.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���г���', '600087.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ӵ�ý', '600088.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ر�繤', '600089.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ơ�ƻ�', '600090.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('S*ST����', '600092.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�̼ιɷ�', '600093.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '600094.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���߿�', '600095.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���컯', '600096.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600097.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ֺ��ɷ�', '600099.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ͬ���ɷ�', '600100.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ǵ���', '600101.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ֹɷ�', '600102.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ɽֽҵ', '600103.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600104.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '600105.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '600107.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ʢ����', '600108.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����֤ȯ', '600109.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�п�Ӣ��', '600110.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ϡ��', '600111.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ɿع�', '600112.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�㽭����', '600113.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600115.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ͽˮ��', '600116.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ظ�', '600117.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й�����', '600118.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ͷ��', '600119.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�㽭����', '600120.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('֣��ú��', '600121.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ƴ�', '600123.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600125.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ֹɷ�', '600126.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҵ', '600127.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ҵ�ɷ�', '600128.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('̫������', '600129.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
commit;
prompt 100 records committed...
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '600130.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600133.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '600136.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������Դ', '600139.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�𷢿Ƽ�', '600143.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����һ��', '600148.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й�����', '600150.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '600153.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ز�', '600159.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��̳����', '600161.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���պ���', '600165.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600166.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ϻ�����', '600170.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ϻ�����', '600171.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й�����', '600176.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST�ƴ�', '600181.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('S��ͨ', '600182.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ز�', '600185.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ˮ��', '600187.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ݸ�', '600190.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ǵ繤', '600192.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ƶ���', '600198.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����', '600201.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���յ���', '600203.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ʸ߿�', '600207.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�޶ٷ�չ', '600209.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ȫʵҵ', '600212.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600215.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600220.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('³����ҵ', '600223.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɽ�', '600225.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ൺ��ҵ', '600229.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ӥ�ɷ�', '600232.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ɽˮ�Ļ�', '600234.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ͭ�����', '600237.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�в�����', '600242.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ຣ����', '600243.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '600249.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ϷĹɷ�', '600250.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�οƲ���', '600255.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����Դ', '600256.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ֿƼ�', '600260.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ST����', '600265.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҩҵ', '600267.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���˷�չ', '600270.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ʵҵ', '600272.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҽҩ', '600276.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҵ', '600278.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('̫���ɷ�', '600281.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('S*ST����', '600286.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ƽ�', '600288.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ˮ�ɷ�', '600291.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ͽ�²�', '600293.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҩҵ', '600297.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST�²�', '600299.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��׼�ɷ�', '600302.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��̩�ɷ�', '600308.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�򻪻�ѧ', '600309.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ũ����ҵ', '600313.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ϻ��һ�', '600315.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ǻ�ѧ', '600319.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�췿��չ', '600322.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '600323.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҩҵ', '600329.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ȼ��', '600333.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600335.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600339.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����Ҹ�', '600340.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '600346.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ɽ������', '600350.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���׵���', '600355.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600358.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��΢����', '600360.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '600363.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600366.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����֤ȯ', '600369.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ũ', '600371.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����', '600751.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600753.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '600754.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�˳�����', '600756.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ý', '600757.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�޼�����', '600759.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�к��ڱ�', '600760.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ͨ��ҽ��', '600763.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�к��ػ�', '600765.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('԰�ǻƽ�', '600766.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600768.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҵ', '600769.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Զ', '600771.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('S*ST����', '600772.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ͼ���è', '600775.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�³�ʵҵ', '600777.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ѻü���', '600778.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ͨ����Դ', '600780.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҩҵ', '600781.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('³�Ŵ�Ͷ', '600783.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('³��Ͷ��', '600784.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�д��ɷ�', '600787.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('³��ҽҩ', '600789.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
commit;
prompt 200 records committed...
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ĳ�', '600790.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ú��Դ', '600792.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ST��ֽ', '600793.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '600795.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('Ǯ������', '600796.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600798.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST����', '600799.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ſ�', '600800.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ˮ��', '600801.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ˮ��', '600802.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�°¹ɷ�', '600803.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ʿ', '600804.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600806.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ҵ�ɷ�', '600807.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ֹɷ�', '600808.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ɽ���ھ�', '600809.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '600810.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600811.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҩ', '600812.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ݽ��', '600814.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ù��ɷ�', '600815.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600816.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ST��ʢ', '600817.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��·�ɷ�', '600818.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ҫƤ����', '600819.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '600820.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ϻ���ó', '600822.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ï�ɷ�', '600823.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '600824.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�»���ý', '600825.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '600826.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '600827.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҩ', '600829.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ͨ', '600830.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '600831.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600832.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��һҽҩ', '600833.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ͨ����', '600834.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ϻ�����', '600835.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��֤ͨȯ', '600837.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ϻ��Ű�', '600838.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ĵ�����', '600839.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�º���ҵ', '600840.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ϲ�ɷ�', '600841.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҩҵ', '600842.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ϲ��건', '600843.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600845.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ͬ�ÿƼ�', '600846.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '600847.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ǹɷ�', '600848.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ҩת��', '600849.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600850.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '600851.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '600853.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '600854.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���쳤��', '600855.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ټ���', '600856.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����״�', '600857.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '600858.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '600859.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600861.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ͨ�Ƽ�', '600862.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ɻ���', '600863.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ͷ�ɷ�', '600864.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ǻ��Ƽ�', '600866.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ͨ������', '600867.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ǻ���Դ', '600869.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�о����', '600872.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ҵ����', '600874.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600875.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й�����', '600877.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '600879.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���𴫲�', '600880.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ɼɼ�ɷ�', '600884.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�귢�ɷ�', '600885.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '600887.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ͼ�����', '600889.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�з��ɷ�', '600890.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ϲɷ�', '600892.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�к�����', '600893.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ſո�', '600897.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600898.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600900.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����֤ȯ', '600958.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600960.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ͷ��³', '600962.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '600965.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '600969.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�вĹ���', '600970.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ʤ�ɷ�', '600973.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '600976.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�˻�ľҵ', '600978.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ų�', '600980.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ȵ�', '600982.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ƻ�', '600985.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '600987.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ƽ�', '600988.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600991.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '600992.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ɽ����', '600995.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
commit;
prompt 300 records committed...
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ͨ', '600998.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ͬúҵ', '601001.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ֹɷ�', '601003.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '601005.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ͼ�����', '601009.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ķ�ɷ�', '601010.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������è', '601015.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '601018.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ƽ�', '601069.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('̫ƽ��', '601099.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('껻���Դ', '601101.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й�����', '601111.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '601116.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ķ��ɷ�', '601126.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ȼ��', '601139.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ǰ��', '601177.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ͨ', '601188.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ˮ��', '601199.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���οƼ�', '601218.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '601222.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ͩ���ɷ�', '601233.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '601238.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���չɷ�', '601311.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������·', '601333.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�»�����', '601336.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ҵ֤ȯ', '601377.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й�����', '601390.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ָ���', '601518.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����֤ȯ', '601555.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ʵҵ', '601588.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й�̫��', '601601.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ع�', '601608.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й�����', '601628.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '601636.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й��罨', '601669.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '601678.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('֣ú��', '601717.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й��ϳ�', '601766.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '601777.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '601799.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й�����', '601800.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й�ʯ��', '601857.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�к�����', '601866.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й�����', '601888.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ͻ��ҵ', '601899.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ͨ', '601908.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��˴�ý', '601928.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Գ���', '601933.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й�����', '601965.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й�����', '601988.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '601998.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�¿�����', '603001.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ȼ��', '603003.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����Ͻ�', '601137.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ҵ����', '601166.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й�����', '601186.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����֤ȯ', '601198.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '601231.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ũҵ����', '601288.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ϼν�', '601313.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��¡����', '601339.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������Դ', '601388.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ǻ�', '601519.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST���', '601558.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ϻ�ҽҩ', '601607.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '601633.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й�����', '601668.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ռ���', '601689.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�緶�ɷ�', '601700.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���֤ȯ', '601788.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ƹ���', '601798.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ִ�', '601872.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ê��', '601890.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ͷ�¼�', '601918.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ӵ�ý', '601929.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ͽ�ҵ', '601969.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й��ع�', '601989.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '603000.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ɽ��ҩ��', '600529.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҵ', '600532.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '600538.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('Ī�߹ɷ�', '600543.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҵ', '600549.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ʱ������', '600551.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Եҩҵ', '600557.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ǹɷ�', '600566.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600569.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����', '600575.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '600577.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���͹���', '600583.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ˮ��', '600585.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('̩���Ƽ�', '600590.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST���', '600598.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����Ƽ�', '600601.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ͷ��', '600606.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ϻ��Ƽ�', '600608.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ϲ����', '603008.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ؿƼ�', '603009.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�϶͹ɷ�', '603011.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('԰�����', '603017.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
commit;
prompt 400 records committed...
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ƹɷ�', '603018.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���չɷ�', '603020.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ȫ���ɷ�', '603030.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '603088.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɽ', '603099.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '603111.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '603118.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��΢�ɷ�', '603123.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�вĽ���', '603126.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ó����', '603128.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '603158.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ֶ�', '603167.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ɯ�հ�˼', '603168.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ʯ��װ', '603169.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ǰ�ɷ�', '603188.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ż�����', '603199.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҩ', '603222.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ɷ��ɷ�', '603268.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����Ƽ�', '603306.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('Ӧ���ɷ�', '603308.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ά��ҽ��', '603309.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ٵ���', '603328.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ǵ���', '603333.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�㽭����', '603338.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ճ�����', '603366.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ե', '603369.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�»���', '603399.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҩҵ', '603456.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ά����˿', '603518.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Թɷ�', '603519.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '603555.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ʢ����', '603558.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���չɷ�', '603600.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����Ƽ�', '603601.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '603606.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�̷���ҵ', '603609.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ŵ���ɷ�', '603611.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '603618.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '603636.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '603686.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ʯӢ�ɷ�', '603688.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���칤��', '603698.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('Ŧ���ɷ�', '603699.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ϲɷ�', '603729.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('¡��ͨ��', '603766.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����߷�', '603788.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��˹��', '603806.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '603828.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '603869.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�°Ĺɷ�', '603889.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '603898.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ľ�', '603899.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ҩ��', '603939.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�е���', '603988.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҵ', '603993.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�̷�ɷ�', '603997.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ʢ��ҩ', '603998.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '601118.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҩ', '600613.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҵ', '600616.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ιɷ�', '600621.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600624.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ɷ�', '600626.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ʵҵ', '600629.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '600631.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�м��ع�', '600634.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ͨ', '600637.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ẽ�ˮ��', '600131.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ֿ���Ƭ', '600135.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ɯ�ɷ�', '600137.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�˷�����', '600141.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ԫ�ɷ�', '600146.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ȷ���չ', '600149.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ά�ƾ���', '600152.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ҵ', '600158.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�޻��ɷ�', '600160.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST��ֽ', '600163.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ع�', '600167.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('̫ԭ�ع�', '600169.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ƺ�����', '600172.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������Դ', '600175.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ïͨ', '600180.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ƽ�', '600183.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ζ��', '600186.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����úҵ', '600188.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ʵҵ', '600191.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������Դ', '600193.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����Ӿ�', '600199.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���յ�', '600202.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����²�', '600206.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�º��б�', '600208.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҩҵ', '600211.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ǿͳ�', '600213.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ˮ��', '600217.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('̫��ҩҵ', '600222.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ݿ�', '600226.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST����', '600228.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ֹɷ�', '600231.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����', '600233.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ڵ���', '600236.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
commit;
prompt 500 records committed...
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ҭ��', '600238.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ͨ�ز�', '600246.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ӳ�����', '600248.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ũ�ɷ�', '600251.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�췽ҩҵ', '600253.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '600257.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ɫ', '600259.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '600262.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������Ϣ', '600271.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������Դ', '600277.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����۾�', '600279.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҩ', '600285.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����˴��', '600287.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�е�Զ��', '600292.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('S����', '600296.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��˳��ҵ', '600305.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�𶫵���', '600310.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ƽ�ߵ���', '600312.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '600318.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600321.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�󶫷�', '600327.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ŀ���', '600336.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���춯��', '600343.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ȫúҵ', '600348.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ػ���ҵ', '600354.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ֽҵ', '600356.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����۳�', '600361.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ͨ�Ϲɷ�', '600365.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ĵ�ý', '600373.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('÷�㼪��', '600868.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�û�����', '600870.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600876.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST����', '600878.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ſƼ�', '600883.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ּ���', '600891.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���չɷ�', '600894.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST����', '600899.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ȼ��', '600917.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ֽ', '600963.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҵ', '600967.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����', '600975.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST����', '600984.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ƴ�ɷ�', '600986.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ӧ��', '600993.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���йɷ�', '600997.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ʵҵ', '601002.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������·', '601006.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��̩¡', '601011.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ֽ���', '601058.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й���', '601088.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й�һ��', '601106.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '601113.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600377.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ƹɷ�', '600378.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ԫ', '600380.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ؼ���', '600383.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ST��̩', '600385.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Խ�ɷ�', '600387.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600388.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ƽ�', '600390.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ɷ��Ƽ�', '600391.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ʵҵ', '600393.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Դúҵ', '600397.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����֮��', '600398.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�춹�ɷ�', '600400.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '600401.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Դ', '600405.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600406.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ѻ���', '600409.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ɷ�', '600416.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600418.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ִ���ҩ', '600420.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ع�', '600421.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '600423.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ɽ���', '600425.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Զ����', '600428.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ں�����', '600433.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600435.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ͨ���ɷ�', '600438.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�𱴿�', '600439.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��֤�ɷ�', '600446.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ĺɷ�', '600448.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '600452.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ʱ���²�', '600458.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���в�ҵ', '600459.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ˮҵ', '600461.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ո۹ɷ�', '600463.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ͽ�ҩҵ', '600466.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600468.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '600469.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '600475.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ֹ�', '600477.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Զ', '600478.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ƹɷ�', '600480.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('˫������', '600481.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ܹɷ�', '600483.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600485.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ҩ�ɷ�', '600488.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������Դ', '600490.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ԫ����', '600491.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
commit;
prompt 600 records committed...
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600495.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ֹ�', '600496.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ͨ��', '600498.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ƴ����', '600499.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ˮ��', '600502.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600505.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '600506.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ϻ���Դ', '600508.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�츻��Դ', '600509.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ҩ�ɷ�', '600511.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ڴｨ��', '600512.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҩҵ', '600513.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600515.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����̿��', '600516.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ŵ���', '600517.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҩҵ', '600518.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ę́', '600519.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�з��Ƽ�', '600520.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҩҵ', '600521.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ƽ�', '600522.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�󺽹ɷ�', '600523.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��԰����', '600525.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ƴﻷ��', '600526.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ϸ���', '600527.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600528.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '600530.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ԥ���Ǧ', '600531.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ϼ����', '600533.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й�����', '600536.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ھ����', '600537.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ʨͷ�ɷ�', '600539.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '600540.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�½��ǽ�', '600545.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ɽ���ƽ�', '600547.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����', '600548.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�~ST����', '600550.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���˿Ƽ�', '600552.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('̫��ˮ��', '600553.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ƽ�', '600556.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '600558.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ϰ׸ɾ�', '600559.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600561.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ƽ�', '600562.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '600565.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ɽӥֽҵ', '600567.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ع�', '600568.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600570.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '600572.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ȫơ��', '600573.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '600576.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ܵ���', '600578.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�컪Ժ', '600579.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��һ����', '600581.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ؿƼ�', '600582.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ƽ�', '600584.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�𾧿Ƽ�', '600586.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�»�ҽ��', '600587.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�㶫��̩', '600589.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST�Ϻ�', '600591.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ϫ�ɷ�', '600592.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ҩ', '600594.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�°��ɷ�', '600596.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҵ', '600597.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��è�̻�', '600599.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ൺơ��', '600600.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ǵ����', '600602.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�б�����', '600604.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ͨ��Դ', '600605.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ʵҽҩ', '600607.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '600609.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST����', '600610.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ϸ���', '600612.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '600614.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ừ�ɷ�', '600615.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������Դ', '600617.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ȼ��', '600618.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��巹ɷ�', '600620.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�α�����', '600622.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('˫Ǯ�ɷ�', '600623.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('PTˮ��', '600625.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ϵ�ɷ�', '600627.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '600628.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ͷ�ɷ�', '600630.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600632.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�㱨��ý', '600633.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ڹ���', '600635.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '600636.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�»���', '600638.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Űٿع�', '600640.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ҵ��ҵ', '600641.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '600643.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ԴЭ��', '600645.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ST����', '600646.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����', '600648.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ͷ��', '600650.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600651.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�껪�ع�', '600653.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ֹɷ�', '600654.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ԪͶ��', '600656.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ӳ�', '600658.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
commit;
prompt 700 records committed...
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST����', '600659.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '600661.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('½����', '600663.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ҩ�ɷ�', '600664.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҩҵ', '600666.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��弯��', '600668.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST����', '600669.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ŀҩҵ', '600671.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST��ʥ', '600672.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ͷ��Դ', '600674.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���˹ɷ�', '600676.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ͨ��', '600677.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ɽ����', '600679.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��輯��', '600681.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ͼ��°�', '600682.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�齭ʵҵ', '600684.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600686.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��̩�ع�', '600687.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ϻ���ë', '600689.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ൺ����', '600690.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ͨ�ɷ�', '600692.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���̹ɷ�', '600694.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ͥͶ��', '600695.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ŷ�Ǽ���', '600697.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ʤ����', '600699.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST����', '600700.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '600702.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����д�', '600704.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�к�Ͷ��', '600705.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ʺ�ɷ�', '600707.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '600708.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ֹɷ�', '600710.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ٻ�', '600712.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ͼ�ҽҩ', '600713.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST����', '600715.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����', '600717.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600718.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɽ', '600720.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ţ����', '600722.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���̹ɷ�', '600723.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ά�ɷ�', '600725.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������Դ', '600726.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ѷ��Ƽ�', '600728.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й��߿�', '600730.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ϻ���', '600731.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('Sǰ��', '600733.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�»���', '600735.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ݸ���', '600736.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '600738.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ɽ������', '600740.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600741.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Զ�ز�', '600743.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600744.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600746.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ʵ��չ', '600748.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600749.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ܹɷ�', '600642.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ɽ����', '600644.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ͬ�ﴴҵ', '600647.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ͷ�ع�', '600649.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ʹ�ɷ�', '600652.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ԥ԰�̳�', '600655.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ŵ�ز�', '600657.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ҫ����', '600660.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ǿ���ع�', '600662.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Դ', '600665.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('̫��ʵҵ', '600667.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST˹��', '600670.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '600673.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�л���ҵ', '600675.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ĵ���', '600678.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ϻ�����', '600680.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ͷ��̩', '600683.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�㴬����', '600685.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ϻ�ʯ��', '600688.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ú����', '600691.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ټ���', '600693.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���׹ɷ�', '600696.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600698.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '600701.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '600703.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600706.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ST��̬', '600709.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ʢ�Ϳ�ҵ', '600711.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ҵ', '600714.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��˹ɷ�', '600716.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ȵ�', '600719.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ٻ���', '600721.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600724.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('³������', '600727.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ٻ�', '600729.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ϻ���÷', '600732.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ʵ�Ｏ��', '600734.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ͺ�', '600737.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɴ�', '600739.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('һ����ά', '600742.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '600745.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ع�', '600747.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҩҵ', '600750.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Դ', '000508.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
commit;
prompt 800 records committed...
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��·����', '000510.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�忪��', '000514.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ٰ��ز�', '000517.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST���', '000520.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000523.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ͷ��', '000526.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ع�', '000529.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ϲɷ�', '000532.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST����', '000535.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ϰ�ҩ', '000538.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ɽ����', '000541.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ԭ����', '000544.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������A', '000547.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000550.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ɳ¡��A', '000553.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('PT����', '000556.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҵ', '000558.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '000561.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000564.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ƽ������', '000001.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���A', '000002.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('PT����A', '000003.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ũ�Ƽ�', '000004.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������Դ', '000005.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҵA', '000006.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '000008.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й�����', '000009.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���', '000010.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҵA', '000011.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ϲ�A', '000012.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*STʯ��A', '000013.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ɳ�ӹɷ�', '000014.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���A', '000016.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���л�A', '000017.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й�A', '000018.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���A', '000019.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���A', '000020.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ƽ�', '000021.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����A', '000022.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���̵ز�', '000024.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����A', '000025.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ǵ�A', '000026.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������Դ', '000027.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ҩһ��', '000028.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���A', '000029.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ز�', '000031.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ɣ��A', '000032.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST�¶�', '000033.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����̩��', '000034.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й����', '000035.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ع�', '000036.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ϵ�A', '000037.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�м�����', '000039.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ز�', '000040.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���޿ع�', '000042.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�к��ز�', '000043.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���֯A', '000045.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ع�', '000046.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ST����', '000047.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '000049.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������A', '000050.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '000055.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����', '000056.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '000058.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '000059.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ũ��Ʒ', '000061.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ڻ�ǿ', '000062.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ͨѶ', '000063.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000065.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ǵ���', '000066.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000068.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ȳ�A', '000069.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000078.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����', '000088.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ڻ���', '000089.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�콡����', '000090.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����Դ', '000096.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ź�ֱ', '000099.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('TCL����', '000100.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�гɹɷ�', '000151.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ԭҩҵ', '000153.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '000155.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ý', '000156.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ؿ�', '000157.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ɽ�ɷ�', '000158.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ʵҵ', '000159.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����г�', '000301.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ļ���', '000333.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('Ϋ����', '000338.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���̵���', '000400.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ˮ��', '000401.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ڽ�', '000402.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ST����', '000403.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ST�ι�', '000405.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000406.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ʤ���ɷ�', '000407.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Դ', '000408.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ɽ���ؿ�', '000409.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000410.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('Ӣ�ؼ���', '000411.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
commit;
prompt 900 records committed...
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '000413.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000415.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ع�', '000416.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ϸʰٻ�', '000417.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('С���A', '000418.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ͨ�̿ع�', '000419.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ͼ��б�', '000421.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����˻�', '000422.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000423.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�칤��е', '000425.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ҵ��ҵ', '000426.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ƶ�', '000428.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������A', '000429.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ֽҵ', '000488.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ɽ��·��', '000498.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������A', '000501.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�̾��ع�', '000502.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ع�', '000503.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST��ý', '000504.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�齭�ع�', '000505.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�麣��', '000507.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ܿع�', '000509.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ϩ̼�²�', '000511.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���鼯��', '000513.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҵ', '000515.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҽѧ', '000516.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ļ�����', '000518.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '000521.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɽA', '000522.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000524.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��̫��', '000525.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ĵ���', '000527.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����', '000528.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '000530.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����', '000533.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '000534.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ӳ�Ƽ�', '000536.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���չ', '000537.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������A', '000539.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����Ͷ', '000540.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ܵ���', '000543.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҵ', '000545.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Բ�ɷ�', '000546.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ͷ��', '000548.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('S����', '000549.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ԫ�Ƽ�', '000551.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Զú��', '000552.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������Ϣ', '000555.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST����', '000557.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ǯ��', '000559.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ٴ�A', '000560.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Դ֤ȯ', '000562.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�¹�ͶA', '000563.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ϿA', '000565.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����Ͻ�', '000568.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ǹɷ�', '000569.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�´���A', '000571.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000572.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�㶫�ʻ�', '000576.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�κ�����', '000578.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '000582.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000585.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Դͨ��', '000586.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('PT������', '000588.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ǭ��̥A', '000589.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ͩ����', '000591.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ƽ̶��չ', '000592.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST����', '000594.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҩ', '000597.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ͷ��', '000598.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ͷ��Դ', '000600.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ܹɷ�', '000601.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ʢ���ҵ', '000603.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '000605.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ý�ع�', '000607.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000610.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ɷ�չ', '000611.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�󶫺�A', '000613.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '000615.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ʯ�ͼò�', '000617.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000618.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�»���', '000620.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ְ���', '000623.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000625.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ï����', '000627.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���·�չ', '000628.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ͭ����ɫ', '000630.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('˳����ҵ', '000631.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ͻ�Ͷ��', '000633.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ï��ʵ��', '000637.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�򷽷�չ', '000638.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ʺ�ҩҵ', '000650.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000651.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ST����', '000653.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ҵ', '000655.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ST����', '000658.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST�ϻ�', '000660.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000661.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҵ', '000663.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '000665.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
commit;
prompt 1000 records committed...
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ü���', '000667.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ٷ�ع�', '000668.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����', '000671.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000673.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ST��ɽ', '000675.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���캣��', '000677.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '000678.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ɽ�ƹɷ�', '000680.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('Զ����Դ', '000683.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ɽ����', '000685.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '000687.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���¿�ҵ', '000688.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������Դ', '000690.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ȵ�', '000692.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000693.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000698.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ģ�ܿƼ�', '000700.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����Ŵ�', '000701.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ʯ��', '000703.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�㽭��Ԫ', '000705.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ұ�ظ�', '000708.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ӱ�����', '000709.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '000712.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002059.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ˮ��', '002060.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ɽ����', '002061.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002062.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('Զ������', '002063.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���就��', '002064.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002065.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��̩�Ƽ�', '002066.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ֽҵ', '002067.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��è�ɷ�', '002068.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ӵ�', '002069.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ں͹ɷ�', '002070.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ӱ��', '002071.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����', '002072.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���عɷ�', '002073.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Դ����', '002074.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ɳ�ֹɷ�', '002075.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ѩ����', '002076.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��۹ɷ�', '002077.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('̫��ֽҵ', '002078.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ݹ��', '002079.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�вĿƼ�', '002080.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����', '002081.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����²�', '002082.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���չɷ�', '002083.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ÿ��ԡ', '002084.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002085.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002086.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ұ��֯', '002087.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('³���ɷ�', '002088.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�º���', '002089.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ǿƼ�', '002090.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���չ�̩', '002091.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��̩��ѧ', '002092.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����Ƽ�', '002093.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ൺ����', '002094.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ⱦ', '002095.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002096.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ɽ������', '002097.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��˹ɷ�', '002098.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҩҵ', '002099.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�쿵����', '002100.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�㶫��ͼ', '002101.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ڸ��ɷ�', '002102.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�㲩�ɷ�', '002103.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�㱦�ɷ�', '002104.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��¡ʵҵ', '002105.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����߿�', '002106.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ֻ�ҽҩ', '002107.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002108.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�˻��ɷ�', '002109.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002110.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������̩', '002111.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ƽ�', '002112.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ع�', '002113.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ƽп��', '002114.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��άͨ��', '002115.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й�����', '002116.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���۹ɷ�', '002117.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҩҵ', '002118.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ǿ����', '002119.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�º��ɷ�', '002120.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��½����', '002121.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '002122.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Źɷ�', '002123.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ɷ�', '002124.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��̶�绯', '002125.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ֹɷ�', '002126.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('¶��úҵ', '002128.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�л��ɷ�', '002129.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ŷ�ɷ�', '002131.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ǿƼ�', '002132.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����', '002133.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002135.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ɴ�', '002136.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('˳�����', '002138.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ذ�ɷ�', '002139.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
commit;
prompt 1100 records committed...
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ʤ��΢', '002141.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002142.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�к��Ѱ�', '002145.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ʢ��չ', '002146.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��γͨ��', '002148.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002149.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ͨ', '002151.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ͨ', '002152.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ʯ����Ϣ', '002153.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST����', '600145.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '600151.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��̩��Դ', '600157.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�㽭�ع�', '600162.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�人�ع�', '600168.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ز�', '600173.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ڻ��ɷ�', '600179.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ɷ�', '600184.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɭ��', '600189.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '600195.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600200.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ͻ���ҵ', '600210.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�㽭ҽҩ', '600216.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ϻ���', '600221.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���컯', '600227.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ݴ�', '600230.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ֽ', '600235.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ҵ�ز�', '600240.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST�ɳ�', '600247.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�к㼯��', '600252.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���þƵ�', '600258.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('·�Ž���', '600263.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����', '600275.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����̳�', '600280.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ֶ�����', '600284.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ͨ', '600289.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������˹', '600295.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('άά�ɷ�', '600300.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ҵ��', '600306.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ٻ�ʵҵ', '600311.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('Ӫ�ڸ�', '600317.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ع�', '600320.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������·', '600326.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���˼Ҿ�', '600337.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ͨ��', '600345.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�㽭��ʢ', '600352.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�е·���', '600357.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ͭҵ', '600362.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ƿ�չ', '600367.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�к�����', '600372.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST����', '600752.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ź�ó', '600755.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������Դ', '600758.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���պ���', '600761.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ʢʵҵ', '600767.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���չɷ�', '600770.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���س�Ͷ', '600773.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ͨ��', '600776.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ˮ����', '600779.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�¸ֹɷ�', '600782.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�»��ٻ�', '600785.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST����', '600788.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҵ', '600791.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��˰�Ƽ�', '600794.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���극��', '601007.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('¡���ɷ�', '601012.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ϴ�ý', '601098.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ĵ�����', '601107.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й���ѧ', '601117.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ˮ��', '601158.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й�����', '601179.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ĿƼ�', '601208.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ع�', '601226.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST����', '601268.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й�ƽ��', '601318.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�¹Ķ���', '601369.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '601515.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й���ҵ', '601600.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '601616.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ƽú�ɷ�', '601666.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��̩֤ȯ', '601688.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ʻ�����', '601718.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '601789.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�к��ͷ�', '601808.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��̩����', '601877.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ú��Դ', '601898.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���¹ɷ�', '000567.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '002655.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ѩ����', '002658.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҵ', '002661.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ʵ��', '002664.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���عɷ�', '002667.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '002670.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����֤ȯ', '002673.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('˳���ɷ�', '002676.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ɭ', '002679.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���޹ɷ�', '002682.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ػ�', '002685.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '002688.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ʯ��װ��', '002691.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�˵ؿƼ�', '002694.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
commit;
prompt 1200 records committed...
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002697.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�½���Դ', '002700.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�㽭����', '002703.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002707.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '002710.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ʢ', '002713.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ش�����', '000837.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�е�¶¶', '000848.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '000852.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҵ', '000859.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������Դ', '000862.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ͳ�', '000868.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ϣ��', '000876.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ͭҵ', '000878.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '000882.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ϸ���', '000886.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ïҵ����', '000889.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000893.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ֹɷ�', '000898.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ƽ�', '000901.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ÿ���', '000905.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Դ�Ƽ�', '000909.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���컯', '000912.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000916.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҩҵ', '000919.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ѵ�ɷ�', '000922.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ǹɷ�', '000926.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ݻƺ�', '000929.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '000932.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '000936.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ϵ���', '000939.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���廯��', '000950.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ӳػ���', '000953.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ͨ�ͳ�', '000957.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ҵ�ɷ�', '000960.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҽҩ', '000963.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ϸ�߿�', '000967.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�п�����', '000970.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ܿƼ�', '000973.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�˳���Ϣ', '000977.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '000980.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ɽú��', '000983.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����Ƽ�', '000988.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000993.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�´�½', '000997.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���궯��', '001696.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ҵ', '002002.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�º����', '002005.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���弤��', '002008.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ܰ�����', '002011.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���¹ɷ�', '002014.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ź�ƽ', '002017.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҩҵ', '002020.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ظ���', '002023.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ɽ������', '002026.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ƥ��', '002029.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ղ���', '002032.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002034.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������չ', '002037.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ͼ���', '002040.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ñ���', '002043.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '002045.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002048.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й�����', '002051.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002054.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�и���Դ', '002057.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('Ӣ����', '000635.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ٸ���', '000657.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ӯ��΢', '000670.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ӿ��й�', '000681.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ʯ��ɫ', '000697.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����Ƽ�', '000711.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���߿�', '002144.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '600138.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('Sɽ����', '600205.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600269.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ɷ�', '600331.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�е��ͨ', '600764.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '601028.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '601566.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ش�ý', '000719.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ԫ֤ȯ', '000728.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ϸ绯��', '000737.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '000757.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ӿ���', '002158.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002166.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002174.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ƺ�����', '002182.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ɷɼ���', '002190.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ӧ��ҩ', '002198.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002206.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ض���', '002213.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�챦�ɷ�', '002220.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���˰�װ', '002228.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�󻪹ɷ�', '002236.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����²�', '002247.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ָ֤��', '000001.ss', to_date('05-02-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ָ֤��', '399001.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ֹɷ�', '600005.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600015.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
commit;
prompt 1300 records committed...
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ܵ���', '600023.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '600035.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�㽭����', '600052.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ŵ���', '600060.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ް�', '600068.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST��ҵ', '600075.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Źɷ�', '600083.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ST����', '600091.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ݷ�չ', '600098.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����·��', '600106.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '600114.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ͼ�߿�', '600122.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ơ��', '600132.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '600156.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ÿ��', '600177.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҽҩ', '600196.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ȫ����', '600218.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ϳ�Ͷ', '600239.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600261.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('Ǯ��ˮ��', '600283.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ɷ�', '600303.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��̫ʵҵ', '600328.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ɷ�', '600353.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600375.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('S*ST����', '600762.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���̼���', '600774.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������¯', '600786.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '600797.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ô�Ͷ��', '600805.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ST��һ��', '600813.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ȱҵ', '600821.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���̼���', '600828.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ʵҵ', '600836.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����Ƽ�', '600844.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST�д�', '600852.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST����', '600860.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST�ǻ�', '600871.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҵ', '600882.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ž��߿�', '600895.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ֽҵ', '600966.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ݶ���', '600983.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����֤ȯ', '600999.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('һ�Ϲɷ�', '601038.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҵ', '601168.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й�����', '601299.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ǵ���', '601567.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('º������', '601699.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ӵ���', '601886.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '601992.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����úҵ', '601225.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('¹�ۿƼ�', '601599.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '601818.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '603002.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600560.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ʥ��', '600593.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '603012.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '603166.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ζҵ', '603288.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҽҩ', '603368.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ܻ���', '603588.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '603678.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҵ', '603799.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '603969.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '600619.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ֶ�����', '600639.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��˶�ɷ�', '600155.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST����', '600178.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '600197.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ɽ��ҵ', '600219.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ʱ�����', '600241.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600268.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ST�ϻ�', '600301.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ͨ�ɷ�', '600330.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '600370.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ͷ����', '600886.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�㰲����', '600979.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ܷ��', '601016.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ͳɿ�ҵ', '600381.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�̽��ɷ�', '600395.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ʤ���', '600410.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ԫ�ɷ�', '600429.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ͨ�ɷ�', '600455.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ͷ��ҵ', '600472.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ͨ���', '600487.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���쳿��', '600501.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���߹ɷ�', '000007.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('PT�к�A', '000015.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����A', '000023.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���¹ɷ�', '000030.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ͨ', '000038.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����', '000048.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�н�����', '000060.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ط���Ϣ', '000070.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�˻�����', '000150.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����Դ', '000166.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ѹ��', '000404.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ST�廷', '000412.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ֻ���', '000420.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�żҽ�', '000430.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������Դ', '000506.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
commit;
prompt 1400 records committed...
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ϻ��', '000519.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����A', '000531.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('TCLͨѶ', '000542.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('̩ɽʯ��', '000554.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ϻ�ҩ', '000566.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('S*ST����', '000583.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '000595.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '000608.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST����', '000621.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й�Զ��', '601919.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '601958.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ʒ���', '601991.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���洫ý', '601999.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����Ƽ�', '603005.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '601169.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ɾ���', '601216.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ӵ���', '601258.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ͨ����', '601328.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '601398.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ɽ', '601579.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й���ұ', '601618.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��̩��ҵ', '601677.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ϻ�����', '601727.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���´�ý', '601801.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '601880.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����֤ȯ', '601901.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '601939.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ּ���', '601996.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '603006.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ʿ��', '600535.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ɽú����', '600546.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɽ', '600555.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600563.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ŵ�', '600571.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600580.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600588.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ʵҵ', '600595.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҵ', '600603.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ڽ�ͨ', '600611.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ʢ�ɷ�', '603010.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ѷ�Ƽ�', '603015.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�п����', '603019.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ͱ�ɷ�', '603077.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ǹɷ�', '603100.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ǽ�', '600266.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�λ���Դ', '600273.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ϸֹɷ�', '600282.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ǵ���', '600290.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ĸ', '600298.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ƹֺ���', '600307.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�鶼����', '600316.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '600325.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɽ', '600332.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '600338.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ǳ�ҩҵ', '600351.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ũ����', '600359.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���޽�ͨ', '600368.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ٴ���', '600865.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('÷������', '600873.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��̩����', '600881.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�½��ں�', '600888.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�к���ʢ', '600896.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ұ����', '600961.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Դú��', '600971.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ɷ�', '600981.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ĵ�����', '600990.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ɽ��', '601000.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ƹ�', '601008.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ﺽ��', '601021.ss', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����͸�', '601100.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�׿��ɷ�', '600376.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '600379.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�㶫����', '600382.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ʹ�ý', '600386.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ɽ�ɷ�', '600389.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ʢ����Դ', '600392.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ɽ�ɷ�', '600396.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��˳�ظ�', '600399.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������Դ', '600403.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��̩����', '600408.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('С��Ʒ��', '600415.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҵ', '600419.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ҩ����', '600422.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��³����', '600426.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҵ', '600432.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('Ƭ���', '600436.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ͨ��ҵ', '600444.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ľ���', '600449.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ѹɷ�', '600456.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ʿ��΢', '600460.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ʯ�ֽҵ', '600462.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�õ���', '600467.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600470.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ʿƼ�', '600476.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ǧ��ҩҵ', '600479.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�緫�ɷ�', '600482.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ũ����', '600486.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�н�ƽ�', '600489.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����֯', '600493.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ۺ�п��', '600497.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
commit;
prompt 1500 records committed...
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�л�����', '600500.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '600503.ss', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ظ�', '600507.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ĵ��', '600510.ss', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ճ���A', '000570.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ԶA', '000573.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ڸ߿�', '000581.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ع�', '000584.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ҷ�鱦', '000587.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ϲ�ź�', '000590.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ͨȼ��', '000593.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ž�����', '000596.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ൺ˫��', '000599.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000602.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ຣ����', '000606.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '000609.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '000612.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ͷ��', '000616.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����Ͳ�', '000619.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ʵҵ', '000622.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���⼯��', '000626.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ʸַ���', '000629.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ľ����', '000632.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�绪�߿�', '000636.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ʳƷ', '000639.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('̩��ɷ�', '000652.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ƹɷ�', '000656.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST�и�', '000659.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ܽ��', '000662.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��γ�Ļ�', '000666.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����Դ', '000669.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ϸ�ˮ��', '000672.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ƕ�Ͷ��', '000676.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000679.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000682.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����֤ȯ', '000686.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ST��ҵ', '000689.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��̫ʵҵ', '000691.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������Դ', '000695.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('S*ST��ֽ', '000699.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ƽ�', '000702.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('˫���Ƽ�', '000707.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����Ǳ�', '000710.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҵ', '000713.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '002240.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ͨ������', '002243.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '002246.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002249.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ϻ���ʿ', '002252.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��½�ع�', '002255.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҵ', '002259.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҩҵ', '002262.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ǹɷ�', '002265.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ʿͨ', '002268.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '002271.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002274.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ѱ��ɷ�', '002277.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002280.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����', '002282.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002285.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����Ƽ�', '002288.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002291.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����̩', '002294.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ԻͿƼ�', '002296.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ʥũ��չ', '002299.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002302.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ϲ���ҵ', '002305.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '002308.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002311.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���¹ɷ�', '002314.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҩҵ', '002317.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ͽ�ɷ�', '002320.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002323.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��̫�Ƽ�', '002326.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ϼ���', '002329.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ҩ', '002332.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ƻ���ʢ', '002335.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���չ��', '002338.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ڿƼ�', '002341.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ƥ��', '002344.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('̩���ع�', '002347.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002350.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '002353.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002356.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002359.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����Ƽ�', '002362.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҩҵ', '002365.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('̫���ɷ�', '002368.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ǵ���', '002371.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '002374.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002377.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Զ�ɷ�', '002380.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����˼׳', '002383.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ԭ����', '002386.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ƽ�', '002389.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002392.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('˫��ɷ�', '002395.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���м���', '002398.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�к��Ƽ�', '002401.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����˿��', '002404.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
commit;
prompt 1600 records committed...
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����', '002407.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002410.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '002413.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ʩ��', '002416.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��̫�Ƽ�', '002540.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��͵���', '002543.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002546.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002549.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ع�', '002552.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('˳������', '002555.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002558.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��һ�', '002561.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ֿƼ�', '002564.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002567.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002570.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002572.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('Ⱥ�����', '002575.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҵ', '002578.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ƽ�', '002581.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��¤����', '002584.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ص���', '002587.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�򰲿Ƽ�', '002590.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ϼ���', '002593.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002596.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ʢͨ�ɷ�', '002599.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ͻ�ͨ', '002602.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('Ҧ���˿�', '002605.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('˴�촬��', '002608.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002611.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ɷ���', '002614.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('¶Ц�Ƽ�', '002617.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��͹ɷ�', '002620.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����', '002623.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '002625.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ɶ�·��', '002628.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�¶��Ҿ�', '002631.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ܹɷ�', '002634.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ƽ�', '002637.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Բ��ҵ', '002640.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��̨����', '002643.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002646.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ƽ�', '002649.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����²�', '002652.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҵ', '000715.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��֥��', '000716.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ظ���ɽ', '000717.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000718.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����̩ɽ', '000720.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ʳ', '000721.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ϸ�չ', '000722.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������Դ', '000723.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������A', '000725.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('³̩A', '000726.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����Ƽ�', '000727.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ྩơ��', '000729.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST����', '000730.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ĵ�����', '000731.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('̩�̼���', '000732.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�񻪿Ƽ�', '000733.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ţɽ', '000735.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�з��ز�', '000736.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�к�����', '000738.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҩҵ', '000739.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������Ϣ', '000748.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('пҵ�ɷ�', '000751.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ط�չ', '000752.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST��ά', '000755.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�»���ҩ', '000756.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�аټ���', '000759.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('˹̫��', '000760.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ؿ�ҵ', '000762.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ϲ��', '002154.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ݿ�ҵ', '002155.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ͨ��΢��', '002156.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ƽ�', '002157.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002159.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST����', '002160.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('Զ����', '002161.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('˹�׿�', '002162.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST����', '002163.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST����', '002164.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�챦��', '002165.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ҵ', '002167.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ڻݳ�', '002168.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ǹ����', '002169.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '002170.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ͭҵ', '002171.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ƽ�', '002172.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ǧ������', '002173.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��½����', '002175.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ص��', '002176.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '002177.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ӻ�����', '002178.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�к����', '002179.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ɿ�', '002180.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ý', '002181.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ͨ', '002183.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ÿ���', '002184.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ƽ�', '002185.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ȫ�۵�', '002186.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
commit;
prompt 1700 records committed...
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ٹɷ�', '002187.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�¼���', '002188.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002189.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ιɷ�', '002191.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('·��ɷ�', '002192.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ɽ������', '002193.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�人����', '002194.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��¡����', '002195.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '002196.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('֤ͨ����', '002197.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002199.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ͷ��̬', '002200.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ŷ��²�', '002201.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ƽ�', '002202.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '002203.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ع�', '002204.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ͳ�ɷ�', '002205.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('׼�͹ɷ�', '002207.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ϸʳǽ�', '002208.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����¡', '002209.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002210.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����²�', '002211.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '002212.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����Ƽ�', '002214.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ŵ����', '002215.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ȫʳƷ', '002216.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST��̩', '002217.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002218.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�㿵ҽ��', '002219.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������Դ', '002221.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����Ƽ�', '002222.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ծҽ��', '002223.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ʿ', '002224.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��͹ɷ�', '002225.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ϻ���', '002226.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ѹ', '002227.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�販�ɷ�', '002229.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ƴ�Ѷ��', '002230.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��άͨ��', '002231.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������Ϣ', '002232.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ƽ���', '002233.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST���', '002234.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ݹɷ�', '002235.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ɷ�', '002237.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������Ѷ', '002238.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ɴ�', '002239.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ѧ', '002241.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '002242.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002244.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����˳��', '002245.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST����', '002248.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����Ƽ�', '002250.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002251.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ʤ', '002253.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('̩���²�', '002254.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ʺ羫��', '002256.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ѧ', '002258.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ά��Ϣ', '002261.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����', '002263.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�»���', '002264.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�㸻�ع�', '002266.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ȼ��', '002267.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '002269.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002270.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ˮ�����', '002273.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002275.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '002276.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�񿪹ɷ�', '002278.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002279.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ѹ�Ƽ�', '002281.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002283.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���䱦', '002286.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҩ', '002287.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��˳����', '002289.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ʢ�²�', '002290.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�·ɶ���', '002292.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ҷ�', '002293.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���չɷ�', '002295.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002298.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('̫������', '002300.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ļ���', '002301.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ӯɭ', '002303.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ӹɷ�', '002304.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�п�����', '002306.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����·��', '002307.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����԰��', '002310.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��̩�ع�', '002312.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�պ�ͨѶ', '002313.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ƽ�', '002315.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ͨѶ', '002316.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ز�', '002318.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ͨ�ɷ�', '002319.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '002322.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002324.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ιɷ�', '002325.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002327.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '002328.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����˹', '002330.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ͨ�Ƽ�', '002331.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('Ӣ����', '002334.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
commit;
prompt 1800 records committed...
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002336.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ƽ�', '002337.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ɵ���', '002339.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002340.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002342.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '002343.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���н���', '002346.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ֹɷ�', '002348.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҩ', '002349.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002351.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��̩�²�', '002352.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ľҵ', '002354.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҵ', '002357.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ɭԴ����', '002358.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ͬ�»���', '002360.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�񽣹ɷ�', '002361.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('¡����е', '002363.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�к����', '002364.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '002366.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('׿���Ƽ�', '002369.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��̫ҩҵ', '002370.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ΰ���²�', '002372.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ǧ���Ƽ�', '002373.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ùɷ�', '002375.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�±���', '002376.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Դ��ҵ', '002378.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('˫���ɷ�', '002381.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҽ��', '002382.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ɽ����', '002384.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ũ', '002385.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ţʳƷ', '002387.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����Ƴ�', '002388.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ű���ҩ', '002390.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҩ', '002393.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '002394.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '002396.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ν�ҷ�', '002397.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002399.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ʡ��ɷ�', '002400.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ͷ�̩', '002402.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��άͼ��', '002405.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('Զ������', '002406.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ڴ�', '002408.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ſ˿Ƽ�', '002409.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�žž�', '002411.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ɭ��ҩ', '002412.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002415.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ԫ��', '002417.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����̳�', '002419.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '002420.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ʵ����', '002421.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҩҵ', '002422.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ԭ�ظ�', '002423.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ݰ���', '002424.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '002425.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ȷ�ɷ�', '002427.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҵ', '002428.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�׳۹ɷ�', '002429.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '002430.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���԰��', '002431.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ű�ҽ��', '002432.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('̫����', '002433.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002435.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ɭ�Ƽ�', '002436.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҩҵ', '002437.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ͨ', '002438.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ǳ�', '002439.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '002440.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ǻ���', '002442.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���޹ܵ�', '002443.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ǿƼ�', '002444.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ع�', '002445.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ʢ·ͨ��', '002446.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('Ҽ�ź���', '002447.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ԭ����', '002448.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002450.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('Ħ������', '002451.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���߼���', '002452.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002453.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��֥�ɷ�', '002454.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ٴ��ɷ�', '002455.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ŷ�ƹ�', '002456.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '002458.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST��ҵ', '002459.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ӷ��ҵ', '002460.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�齭ơ��', '002461.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002462.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '002463.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����Ƽ�', '002464.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ҵ', '002466.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002467.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ά����', '002469.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002470.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('˫������', '002472.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ʥ����', '002473.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ż�����', '002474.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ӥũ��', '002477.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002479.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '002480.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('˫��ʳƷ', '002481.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
commit;
prompt 1900 records committed...
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ɷ�', '002483.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '002484.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ϣŬ��', '002485.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ع�', '002487.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��̹ɷ�', '002488.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�㽭��ǿ', '002489.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ɽ��ī��', '002490.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ͨ������', '002491.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '002492.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��˹�ɷ�', '002494.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��¡�ɷ�', '002495.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Է�ɷ�', '002496.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ż�����', '002497.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���¹ɷ�', '002498.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ֻ���', '002499.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ɽ��֤ȯ', '002500.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '002502.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002503.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����΢��', '002504.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҵ', '002505.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST����', '002506.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ե��', '002507.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ϰ����', '002508.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ģ', '002510.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��˳����', '002511.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ﻪ����', '002512.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002513.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ܰ�Ƽ�', '002514.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ֻ���', '002515.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���տ���', '002516.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ʿ��', '002518.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ӵ���', '002519.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�շ�����', '002520.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����²�', '002521.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�㽭�ڳ�', '002522.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002523.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002524.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ɽ�����', '002526.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ʱ��', '002527.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('Ӣ����', '002528.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Դ��е', '002529.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ᶫ�ɷ�', '002530.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��˳����', '002531.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�½��ҵ', '002532.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '002534.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ػ�', '002535.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ùɷ�', '002536.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002537.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('˾����', '002538.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�¶�����', '002539.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��·�ֹ�', '002541.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����Ƽ�', '002544.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002545.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���˾���', '002547.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ũ', '002548.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ǧ����ҩ', '002550.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҽ��', '002551.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ϸ����', '002553.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��¡�ɷ�', '002556.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ǢǢʳƷ', '002557.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '002559.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ͨ��ɷ�', '002560.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ֵܿƼ�', '002562.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ɭ������', '002563.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ʢҩҵ', '002566.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '002568.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ɭ�ɷ�', '002569.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '002571.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002573.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����鱦', '002574.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ͨ�ﶯ��', '002576.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�о�����', '002579.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ʥ���ɷ�', '002580.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002582.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ܴ�', '002583.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('˫���²�', '002585.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('Χ���ɷ�', '002586.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ʷ����', '002588.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002591.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ƽ�', '002592.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ǵ�', '002594.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����Ƽ�', '002595.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ʵҵ', '002597.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ɽ���¹�', '002598.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���۴Ų�', '002600.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҩҵ', '002603.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002604.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '002606.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002607.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��˳�Ƽ�', '002609.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����Ƽ�', '002610.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���˹ɷ�', '002612.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����˹', '002615.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���༯��', '002616.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ƽ�', '002618.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҵ', '002619.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002621.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002622.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ڹɷ�', '002624.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�˲�����', '002627.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
commit;
prompt 2000 records committed...
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ͷ�', '002629.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������Դ', '002630.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ѧ', '002632.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST���', '002633.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ƽ�', '002635.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ϲ��', '002638.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ѩ�˹ɷ�', '002639.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���߹ɷ�', '002641.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��֮��', '002642.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ҩ', '002644.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ƽ�', '002645.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ڹɷ�', '002647.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ӽ�ʳƷ', '002650.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '002651.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��˼��', '002653.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ƽ�', '002654.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ū��·', '002656.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�пƽ��', '002657.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��̩����', '002659.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '002662.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�հ�԰��', '002663.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�׺�����', '002665.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002666.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002668.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����²�', '002669.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ȫ�ɷ�', '002671.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ҵ�Ƽ�', '002674.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҩҵ', '002675.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�㽭����', '002677.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�齭����', '002678.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ƺ���е', '002680.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ܴ�Ƽ�', '002681.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����', '002683.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002686.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ΰ�', '002687.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002689.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ǹ��', '002690.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('Զ�̵���', '002692.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('˫��ҩҵ', '002693.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ϻ�', '002695.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ʵ�ɷ�', '002698.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ʢ�Ļ�', '002699.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����', '002701.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ʳƷ', '002702.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�±��ɷ�', '002705.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ŵ���', '002706.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '002708.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ŷ�ָ���', '002711.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('˼����ý', '002712.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ԭ�ɷ�', '002714.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ƹɷ�', '002715.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ҵ', '002716.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����԰��', '002717.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ѱ����', '002718.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ȥ��', '002719.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��һ�Ļ�', '002721.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ֹɷ�', '002722.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002723.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002724.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('Ծ��ɷ�', '002725.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ʳ', '002726.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('һ����', '002727.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002729.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ƽ�', '002730.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ͻ��鱦', '002731.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҵ', '002732.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��躹ɷ�', '002733.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '002734.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����²�', '002735.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҩҵ', '002737.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�п���Դ', '002738.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ժ��', '002739.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���϶�', '002740.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�⻪�Ƽ�', '002741.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ʥ�ز�', '002742.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���͸ֹ�', '002743.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��̳�ɷ�', '002746.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��˹��', '002747.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ʵҵ', '002748.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '002749.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҩҵ', '002750.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����GAC1', '031005.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ʸ�AGP1', '038011.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ط�JFP1', '038014.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�κ�YHP1', '038015.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����JQP1', '038016.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�SFP1', '038017.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����֤ȯ', '000750.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ݷ�չ', '000753.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ְ��', '000761.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002468.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�г�����', '002471.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ѷ����', '002475.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '002478.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '002482.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST����', '002127.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST����', '002134.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ʵ���', '002137.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����Ƽ�', '002140.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ӡ�ʹ�ý', '002143.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
commit;
prompt 2100 records committed...
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Բ֧��', '002147.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ͨ��װ��', '002150.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000763.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ͨ������', '000766.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '000767.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�к��ɻ�', '000768.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST���', '000769.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�㷢֤ȯ', '000776.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�к˿Ƽ�', '000777.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000778.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ƽׯ��Դ', '000780.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '000782.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����֤ȯ', '000783.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�人����', '000785.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���½���', '000786.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST����', '000787.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ҽҩ', '000788.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '000790.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����Ͷ', '000791.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�κ��ɷ�', '000792.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ŵ�ý', '000793.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('̫ԭ����', '000795.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ʳ�ɷ�', '000796.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ˮ��ҵ', '000798.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ƹ���', '000799.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('һ���γ�', '000800.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ĵ�����', '000801.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����Ļ�', '000802.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����', '000803.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST�׻�', '000805.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '000807.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����³�', '000809.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ά����', '000810.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��̨����', '000811.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������Ҷ', '000812.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ɽ��֯', '000813.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ֽҵ', '000815.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000817.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���󻯹�', '000818.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����˳�', '000819.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ǹɷ�', '000820.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ɽ���', '000821.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST����', '000822.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000823.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ɣ�»���', '000826.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST����', '000827.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ݸ�ع�', '000828.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ع�', '000829.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('³������', '000830.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ϡ��', '000831.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST����', '000832.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ƕ���', '000835.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ï�Ƽ�', '000836.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���˵ز�', '000838.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ź���', '000839.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ï�ɷ�', '000850.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ߺ�ɷ�', '000851.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����װ��', '000856.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('˳��ũҵ', '000860.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ӡ�ɷ�', '000861.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '000863.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000866.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ԣA', '000869.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '000875.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('Ϋ���ػ�', '000880.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000881.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������Դ', '000883.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ͬ��ˮ��', '000885.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ж��ɷ�', '000887.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��üɽA', '000888.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ʤ', '000890.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('˫�㷢չ', '000895.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����չ', '000897.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ܹɷ�', '000899.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ִ�Ͷ��', '000900.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����', '000902.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ڶ���', '000903.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '000906.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ǿƼ�', '000910.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҵ', '000911.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('Ǯ��Ħ��', '000913.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ɽ����', '000915.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��㴫ý', '000917.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ο���', '000918.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ϸ���ͨ', '000920.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ӱ�����', '000923.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ںϻ���', '000925.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('һ������', '000927.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�иֹ���', '000928.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000930.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�йش�', '000931.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ɷ�', '000933.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������Դ', '000937.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ϲ�ɷ�', '000938.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������Ϣ', '000948.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���绯��', '000949.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й�����', '000951.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ҩҵ', '000952.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ع�', '000955.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������Դ', '000958.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
commit;
prompt 2200 records committed...
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�׸ֹɷ�', '000959.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ͻ���', '000961.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҵ', '000962.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�챣����', '000965.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Դ����', '000966.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ú����', '000968.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ع�', '000971.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���л�', '000972.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��̩��Դ', '000975.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���͹ɷ�', '000976.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000978.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�к�ɷ�', '000979.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ڹɷ�', '000981.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���컪��', '000985.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000987.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��֥��', '000989.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��־�ɷ�', '000990.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��̨��ҵ', '000995.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й�����', '000996.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('¡ƽ�߿�', '000998.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ԥ�ܿع�', '001896.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ºͳ�', '002001.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ΰ�ǹɷ�', '002003.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ӱ̩', '002004.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����Ƽ�', '002006.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002007.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '002009.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '002012.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�к�����', '002013.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*STϼ��', '002015.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҵ', '002016.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���Ź���', '002018.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ڷ��θ�', '002019.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�н���Դ', '002021.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002024.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '002025.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ϲ�ع�', '002027.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('˼Դ����', '002028.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ﰲ����', '002030.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ֹɷ�', '002031.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002033.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ҵ', '002036.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('˫��ҩҵ', '002038.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ǭԴ����', '002039.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ǻ���ҵ', '002041.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɫ��', '002042.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002044.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���пƼ�', '002046.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ͬ����о', '002049.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '002050.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ͬ�޵���', '002052.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����λ�', '002053.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '002055.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��궫��', '002056.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����̩', '002058.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002260.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '002272.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��̫�ɷ�', '002284.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����²�', '002297.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����Ƽ�', '002309.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ӣũҵ', '002321.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����˹��', '002333.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����', '002345.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����Ȧ', '002355.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002367.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('³�ỷ��', '002379.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '002391.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���˴�', '002403.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ߵº���', '002414.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ʢ�ɷ�', '002418.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ʤ������', '002426.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002434.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ҵ��', '002441.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ǹ��', '002449.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҵ', '002457.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ͨ��', '002465.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ī�ɷ�', '002476.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����', '002486.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ʢʯ��', '002493.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Դ����', '002501.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�������', '002509.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('̩�ǹɷ�', '002517.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ʤ��ɽ��', '002525.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�𱭵繤', '002533.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�л�����', '002542.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ݲ���', '002554.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ϻ�����', '002565.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�װؿƼ�', '002577.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ҽҩ', '002589.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '002601.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '002613.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����', '002626.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�𰲹���', '002636.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ʯ��', '002648.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ï˶��Դ', '002660.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '002672.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ʨ�Ƽ�', '002684.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����ɷ�', '002696.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��Ͳ���', '002709.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '002720.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
commit;
prompt 2300 records committed...
insert into TB_STOCK_MAIN (name, code, end_date)
values ('̨����ҩ', '002728.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����֤ȯ', '002736.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('ľ��ɭ', '002745.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����EJC1', '031007.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ɫ�ɷ�', '000758.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ֶ��˲�', '002130.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST����', '000765.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('*ST����', '000779.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������', '000789.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�й�����', '000797.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Ͷ��', '000806.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000816.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('̫�ֲ���', '000825.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ǹɷ�', '000833.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('����Һ', '000858.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ɽ�ɷ�', '000877.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000892.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��һ�Ƽ�', '000908.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���ſ���', '000921.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�Ĵ�˫��', '000935.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ԭ����', '000956.sz', to_date('31-12-2012', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��̩�Ƽ�', '000969.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('������ҵ', '000982.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��������', '000999.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�����ɷ�', '002010.sz', to_date('04-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('�ƻ�����', '002022.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('���۹ɷ�', '002035.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
insert into TB_STOCK_MAIN (name, code, end_date)
values ('��ӥ�ɷ�', '002047.sz', to_date('05-03-2015', 'dd-mm-yyyy'));
commit;
prompt 2328 records loaded
set feedback on
set define on
prompt Done.
